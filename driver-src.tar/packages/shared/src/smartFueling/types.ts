/**
 * Smart Fueling — shared domain contracts + defaults (pure). Distinct from `fuel.ts` (the fuel-transaction
 * domain): this module is about ROUTE fuel PLANNING — stations, prices, discount model, and the per-org
 * planning policy. Chain-agnostic by design; Pilot is loaded as data, never hardcoded in logic.
 * See docs/plans/SMART-FUELING-PLAN.md.
 */

/** A physical truck-stop location (global reference fact). */
export interface FuelStation {
  id: string;
  brand: string; // 'pilot' | 'flying_j' | 'one9' | ... — never special-cased in logic; policy lives in settings
  storeNumber: string | null;
  name: string | null;
  lat: number;
  lng: number;
  state: string | null; // 2-letter; drives avoid-states
  exit: string | null;
  hasDiesel: boolean;
  hasDef: boolean;
  status: "active" | "closed";
}

/** A price observation for a station+product (net is org-specific via the discount deal). */
export interface FuelPrice {
  stationId: string;
  product: "diesel" | "def";
  postedPrice: number | null;
  netPrice: number | null;
  source: string; // 'pilot_email' | 'efs'
  observedAt: string; // ISO
}

export type DiscountType = "flat" | "retail_minus" | "cost_plus" | "per_site" | "none";
export interface DiscountRule {
  brand: string;
  type: DiscountType;
  /** Cents per gallon: retail_minus/flat subtract; cost_plus adds. */
  centsOff: number;
}

/** The truck combination's routing profile (US customary as stored; converted to HERE units at call time). */
export interface TruckProfile {
  heightIn: number;
  lengthIn: number;
  widthIn: number;
  axleCount: number;
  grossWeightLb: number;
}

/** Trailer/equipment a carrier typically hauls. Sets the plan form's default so hazmat is never
 *  presumed; a per-plan selection still overrides. "reefer" additionally enables reefer-fuel modeling. */
export type EquipmentType =
  | "dry_van" | "reefer" | "flatbed" | "container" | "tanker" | "auto_carrier" | "bulk" | "other";
export const EQUIPMENT_TYPES: { value: EquipmentType; label: string }[] = [
  { value: "dry_van", label: "Dry van" },
  { value: "reefer", label: "Reefer (refrigerated)" },
  { value: "flatbed", label: "Flatbed" },
  { value: "container", label: "Intermodal container" },
  { value: "tanker", label: "Tanker" },
  { value: "auto_carrier", label: "Auto carrier" },
  { value: "bulk", label: "Bulk / pneumatic" },
  { value: "other", label: "Other" },
];

/** Per-org planning policy + safety parameters. Every fleet-specific value is configuration, not code. */
export interface RouteFuelSettings {
  reservePct: number;
  corridorMiles: number;
  minPurchaseGal: number;
  mpgSafetyFactor: number;
  deviationThresholdMi: number;
  priceTtlHours: number;
  /** true = top off at every stop. false = min-drawdown: buy only enough to reach the next cheaper stop. */
  alwaysFillFull: boolean;
  /** When min-drawdown is active, cap a non-cheapest partial fill at this % of tank (full fill only at the cheapest reachable stop). */
  fillCapPct: number;
  avoidStates: string[];
  /** Extra detour miles charged to an opposite-side (of travel) station — a divided-highway back-track. 0 = off. */
  oppositeSideAccessMiles: number;
  /** Refuel only in the last N miles of range (run the tank down toward reserve → fewest stops, always full). */
  refuelBandMiles: number;
  /** Below this % of tank with no preferred station reachable = a TRUE emergency (missed-fill splash). Above it,
   *  a no-preferred stretch is an OFF-NETWORK stop (flagged), never a fake "emergency". */
  criticalFuelPct: number;
  /** States to top off before entering (sparse fueling — e.g. Massachusetts has one truck stop) — stations here stay usable. */
  fuelBeforeStates: string[];
  avoidBrands: string[];
  preferredBrands: string[];
  emergencyBrands: string[];
  /** Truck-stop networks this org has turned ON — a hard registry filter applied BEFORE the solver
   *  (the registry may hold more networks than an org uses). Empty is not allowed (resolve falls back). */
  enabledBrands: string[];
  emergencyFillGallons: number;
  planDef: boolean;
  /** Carrier's usual trailer/equipment — the plan form default (per-plan override wins). */
  defaultEquipmentType: EquipmentType;
  defaultProfile: TruckProfile;
}

export const DEFAULT_ROUTE_FUEL_SETTINGS: RouteFuelSettings = {
  reservePct: 20,
  corridorMiles: 2.5,
  minPurchaseGal: 50,
  mpgSafetyFactor: 0.9,
  deviationThresholdMi: 3,
  priceTtlHours: 72, // a manually-uploaded daily report can lag 1-2 days; treat quotes within 3 days as current
  alwaysFillFull: true, // always top off (full tank). Min-drawdown is opt-in per org, not the default.
  fillCapPct: 75,
  avoidStates: ["CA"],
  oppositeSideAccessMiles: 2, // interstate truck stops sit at interchanges → opposite side ≈ a real crossover
  refuelBandMiles: 150, // defer fueling to the last ~150 mi of range so the truck fuels near reserve, not early
  criticalFuelPct: 10, // emergency only if under 10% with no Pilot/Flying J reachable (driver missed a planned fill)
  fuelBeforeStates: ["MA"], // top off before entering — Massachusetts has essentially one truck stop
  avoidBrands: ["one9"],
  preferredBrands: ["pilot", "flying_j"],
  emergencyBrands: ["one9"],
  enabledBrands: ["pilot", "flying_j", "one9"],
  emergencyFillGallons: 50,
  planDef: false,
  defaultEquipmentType: "dry_van",
  defaultProfile: { heightIn: 162, lengthIn: 840, widthIn: 102, axleCount: 5, grossWeightLb: 80000 },
};
