/**
 * Smart-fueling solver (pure). ONE integrated walk down the route that respects fuel AND hours-of-service
 * together, so the plan is a single Start → stop → … → End itinerary rather than a fuel plan with HOS bolted on.
 *
 * At every point the truck may drive only as far as the binding limit of: fuel above reserve, the legal drive
 * clock (min of 11h drive / 14h shift / 60-70h cycle), and the 30-min break interval. Rules (audit-hardened):
 *  1. Never arrive below reserve (incl. detour + reefer burn).                     [safety > cost, always]
 *  2. Prefer discounted, non-avoided stations; California/avoided = emergency only, capped at the 50-gal splash.
 *  3. Always full fills (top off) — the only capped fill is the California emergency splash.
 *  4. Cheapest reachable wins among preferred.
 *  5. Breaks/resets are NEVER emitted as their own stops — the itinerary is FUEL STOPS ONLY. HOS only TIMES the
 *     fuel: a fuel stop landing where the 30-min break comes due is tagged coversBreak (fuel + break = time saved).
 *  6. When the legal drive clock is exhausted before the destination, the 10-hour reset is applied SILENTLY. A
 *     fill is combined into that rest only as a CONVENIENCE — a station near the limit AND a meaningful fill;
 *     otherwise it just rests (fuel is planned by RANGE, never around break/rest time).
 * INFEASIBLE is a LOUD state, never a best-guess stop. Correctness is tested empirically.
 */
import { galPerMile } from "./consumption.js";
import { hoursFromMs } from "./units.js";
import type { RouteFuelSettings } from "./types.js";
import type { TruckFuelState } from "./truckState.js";
import { isPreferred, cheapest, nearest } from "./stationSelect.js";
import { chooseFill } from "./fillPolicy.js";

const H = 3_600_000;
const DRIVE_RESET_MS = 11 * H; // fresh drive clock after a 10-hour reset
const SHIFT_RESET_MS = 14 * H; // fresh shift window after a 10-hour reset
const BREAK_INTERVAL_MS = 8 * H; // driving time allowed between required 30-min breaks
const BREAK_MS = 30 * 60_000;
const FUEL_SERVICE_MS = 45 * 60_000; // on-duty time consumed at a fuel stop (also covers the break)

export interface SolverStation {
  id: string;
  brand: string;
  state: string | null;
  /** Miles along the route ahead of the truck's current position. */
  milesAhead: number;
  /** Approx round-trip detour off the route to the pump. */
  detourMiles: number;
  /** Net $/gal (diesel). null = price unknown for this station. */
  netPrice: number | null;
  /** true = netPrice is a history/brand estimate (Phase 5), not a fresh quote. Biases selection toward real prices. */
  priceEstimated?: boolean;
}

/** Live HOS clocks fed to the solver (null → that clock unknown; the solver then plans on fuel alone + flags it). */
export interface HosState {
  driveRemainingMs: number | null;
  shiftRemainingMs: number | null;
  cycleRemainingMs: number | null;
  breakRemainingMs: number | null; // driving time until the 30-min break is due
}

export interface FuelPlanInput {
  distanceToGoMiles: number;
  stations: SolverStation[];
  truck: TruckFuelState;
  settings: RouteFuelSettings;
  avgSpeedMph?: number;
  hos?: HosState;
  /** Route mile where the truck crosses into an avoided state (e.g. California). undefined = no avoided border ahead. */
  avoidedBorderMiles?: number;
  /** Fuel % at/above which the pre-border top-off is skipped (default 80 — enter the avoided state full unless already near-full). */
  borderTopOffPct?: number;
}

export type PlanStatus = "ok" | "emergency_used" | "infeasible";

export interface PlannedStop {
  /** Miles from the start where this stop happens. */
  milesAhead: number;
  /** The fuel station, or null for a rest-only stop (a required reset/break with no fuel purchase). */
  station: SolverStation | null;
  arrivalGal: number;
  fillGal: number;
  netPrice: number | null;
  cost: number | null;
  isEmergency: boolean;
  kind: "fuel" | "rest";
  /** This stop satisfies the required 30-min break. */
  coversBreak: boolean;
  /** This stop includes a 10-hour reset (overnight). */
  isOvernight: boolean;
  /** Legal drive hours remaining on arrival (before any reset here) — for the itinerary. */
  driveHoursLeftOnArrival: number | null;
  /** This fuel stop is the mandated top-off just before entering an avoided state (e.g. the California border). */
  isBorderTopOff: boolean;
  /** This is a min-drawdown partial fill (bought only enough to reach the next cheaper stop), not a full top-off. */
  isMinFill: boolean;
  /** Not a Pilot/Flying J — an off-network stop suggested only because no preferred station was reachable (a
   *  Pilot coverage gap). NOT an emergency; surfaced so the dispatcher knows a preferred station is missing. */
  isOffNetwork: boolean;
}

export interface FuelPlan {
  status: PlanStatus;
  stops: PlannedStop[];
  reachesDestination: boolean;
  totalGallons: number;
  totalCost: number | null;
  arrivalFuelPct: number | null;
  savingsVsNaive: number | null;
  flags: string[];
}

const EPS = 1e-6;

interface GreedyResult {
  stops: PlannedStop[];
  reaches: boolean;
  arrivalGal: number | null;
  usedEmergency: boolean;
  usedAvoidedState: boolean;
  usedReset: boolean;
  hosLimited: boolean;
  infeasible: boolean;
  droppedNoPrice: boolean;
  usedBorderTopOff: boolean;
  usedMinFill: boolean;
  usedEstimatedPrice: boolean;
  usedOffNetwork: boolean;
}

/**
 * One integrated greedy pass. `select` chooses among reachable preferred stations ("smart" = cheapest,
 * "naive" = nearest) so the same safety + HOS machinery produces both the plan and its savings baseline.
 */
function runGreedy(input: FuelPlanInput, select: (opts: SolverStation[]) => SolverStation): GreedyResult {
  const { distanceToGoMiles: dest, truck, settings: cfg } = input;
  const avgSpeed = input.avgSpeedMph ?? 55;
  const gpm = galPerMile(truck.burn, avgSpeed);
  const galFor = (mi: number) => mi * gpm;
  const msPerMile = H / avgSpeed;
  const miPerMs = avgSpeed / H;
  const usable = truck.usableGal;
  const reserve = truck.reserveGal;
  const weightCap = truck.weightLegalFillGal;
  const tankCap = truck.effectiveTankCapacityGal;
  const avoidedBorderMi = input.avoidedBorderMiles;
  const topOffPct = input.borderTopOffPct ?? 80;
  const stations = [...input.stations].sort((a, b) => a.milesAhead - b.milesAhead);

  const hos = input.hos;
  const hosKnown = !!hos && (hos.driveRemainingMs != null || hos.shiftRemainingMs != null || hos.cycleRemainingMs != null);
  let drive = hos?.driveRemainingMs ?? Infinity;
  let shift = hos?.shiftRemainingMs ?? Infinity;
  let cycle = hos?.cycleRemainingMs ?? Infinity;
  let brk = hos?.breakRemainingMs ?? Infinity;
  const legalDriveMsNow = () => Math.min(drive, shift, cycle);

  const stops: PlannedStop[] = [];
  const used = new Set<string>();
  let pos = 0;
  let gal = truck.gallonsOnHand ?? 0;
  let usedEmergency = false;
  let usedAvoidedState = false;
  let usedReset = false;
  let hosLimited = false;
  let droppedNoPrice = false;
  let usedBorderTopOff = false;
  let borderToppedOff = false; // guard so we top off before the avoided border at most once
  let usedMinFill = false;
  let usedEstimatedPrice = false;
  let usedOffNetwork = false;

  const done = (reaches: boolean, infeasible: boolean, arrivalGal: number | null): GreedyResult => ({
    stops, reaches, arrivalGal, usedEmergency, usedAvoidedState, usedReset, hosLimited, infeasible, droppedNoPrice, usedBorderTopOff, usedMinFill, usedEstimatedPrice, usedOffNetwork,
  });

  const COMBINE_BAND_MI = 75; // a reset combines with a fuel stop within this many miles before the drive limit

  // Apply a fuel stop: drive to it, fill (full / emergency-sized / CA-capped), optionally reset here.
  const applyFuelStop = (pick: SolverStation, emergency: boolean, overnight: boolean, borderTopOff = false, offNetwork = false) => {
    const dist = pick.milesAhead - pos;
    const arrivalGal = gal - galFor(dist + pick.detourMiles);
    const legMs = dist * msPerMile;
    drive -= legMs; shift -= legMs; cycle -= legMs; brk -= legMs;
    const breakWasDue = hosKnown && brk <= H;
    if (pick.priceEstimated && pick.netPrice != null) usedEstimatedPrice = true;
    const { fillGal: fill, isMinFill: minFill, isAvoidedState } = chooseFill({
      pick, arrivalGal, emergency, overnight, borderTopOff, cfg, usable, reserve, weightCap, tankCap, gpm, dest, stations, used, galFor,
    });
    if (isAvoidedState) usedAvoidedState = true;
    if (minFill) usedMinFill = true;
    brk = BREAK_INTERVAL_MS; // a fuel stop (>=30 min) covers the break
    if (overnight) { drive = DRIVE_RESET_MS; shift = SHIFT_RESET_MS; usedReset = true; hosLimited = true; }
    else { shift -= FUEL_SERVICE_MS; cycle -= FUEL_SERVICE_MS; }
    gal = arrivalGal + fill;
    stops.push({
      milesAhead: pick.milesAhead, station: pick, arrivalGal, fillGal: fill, netPrice: pick.netPrice,
      cost: pick.netPrice != null ? pick.netPrice * fill : null, isEmergency: emergency, kind: "fuel",
      coversBreak: breakWasDue, isOvernight: overnight, driveHoursLeftOnArrival: hosKnown ? hoursFromMs(Math.min(drive, shift, cycle)) : null,
      isBorderTopOff: borderTopOff, isMinFill: minFill, isOffNetwork: offNetwork,
    });
    used.add(pick.id);
    pos = pick.milesAhead;
  };

  // A required 10-hour reset with no fuel stop in reach: apply it SILENTLY (advance + reset the clocks) so the
  // route stays legal, but never emit a rest node — the itinerary shows fuel stops only.
  const silentResetAt = (atMile: number) => {
    gal -= galFor(atMile - pos);
    drive = DRIVE_RESET_MS; shift = SHIFT_RESET_MS; brk = BREAK_INTERVAL_MS; usedReset = true; hosLimited = true;
    pos = atMile;
  };

  // Choose among reachable stations, honoring the emergency rule STRICTLY. A stop is only "emergency" when the
  // truck is genuinely stuck: (a) the nearest reachable pump is inside an avoided state (e.g. already in CA with
  // no preferred way out), or (b) the truck is under criticalFuelPct with no Pilot/Flying J reachable (a missed
  // planned fill). Any OTHER no-Pilot stretch is an OFF-NETWORK stop (flagged) — never a fake emergency.
  const pickStop = (opts: SolverStation[]): { pick: SolverStation; emergency: boolean; offNetwork: boolean } => {
    const preferredPriced = opts.filter((x) => isPreferred(x, cfg) && x.netPrice != null);
    if (opts.some((x) => isPreferred(x, cfg) && x.netPrice == null)) droppedNoPrice = true;
    if (preferredPriced.length > 0) return { pick: select(preferredPriced), emergency: false, offNetwork: false };
    const near = opts.reduce((a, b) => (a.milesAhead <= b.milesAhead ? a : b));
    const nearInAvoided = near.state != null && cfg.avoidStates.includes(near.state);
    const curPct = tankCap > 0 ? (gal / tankCap) * 100 : 0;
    if (nearInAvoided || curPct <= cfg.criticalFuelPct + EPS) {
      usedEmergency = true;
      return { pick: near, emergency: true, offNetwork: false };
    }
    usedOffNetwork = true;
    return { pick: near, emergency: false, offNetwork: true };
  };

  // Loop guard: every iteration provably advances `pos` (a fuel stop, a silent break, or a silent reset) or
  // returns, so this only backstops a true bug — size it to also cover HOS break/reset segments on long routes
  // (a sparse-station cross-country trip needs many silent resets) so a valid plan is never cut off as infeasible.
  const guardMax = stations.length * 2 + Math.ceil(dest / 50) + 12;
  for (let guard = 0; guard <= guardMax; guard++) {
    const fuelMi = Math.max(0, gal - reserve) / gpm;
    const driveMi = legalDriveMsNow() * miPerMs; // Infinity when HOS unknown
    const breakMi = brk * miPerMs;
    const remaining = dest - pos;
    const windowMi = Math.min(fuelMi, driveMi);

    // Pre-border top-off (avoided-state rule, e.g. California): if the avoided border lies ahead and the truck
    // would cross it below the top-off threshold, fill up at the furthest reachable preferred station before the
    // line so it enters the avoided state as full as possible. Skipped when it would already cross at/above the
    // threshold (default 85%), or when no station sits between here and the border. Checked BEFORE "reached" so a
    // truck that could coast into the state on its current tank is still told to top off first.
    if (avoidedBorderMi != null && !borderToppedOff && pos < avoidedBorderMi - EPS) {
      // Top off at the LAST preferred (Pilot/FJ) station before the avoided line so the truck ENTERS the state
      // full. Fire only once that last-before-border station is reachable in the CURRENT window — so on a long
      // route we do NOT top off hundreds of miles early: the truck drives toward it by normal range planning +
      // silent rests first, and tops off only when it's genuinely the last stop before the line. Skipped when the
      // truck would already cross at/above the threshold.
      const lastPreBorder = stations
        .filter((x) => !used.has(x.id) && x.milesAhead > pos + EPS && x.milesAhead <= avoidedBorderMi + EPS
          && isPreferred(x, cfg) && x.netPrice != null)
        .reduce<SolverStation | null>((best, x) => (best == null || x.milesAhead > best.milesAhead ? x : best), null);
      if (lastPreBorder != null && (lastPreBorder.milesAhead - pos) + lastPreBorder.detourMiles <= windowMi + EPS) {
        const galAtBorder = gal - galFor(avoidedBorderMi - pos);
        const pctAtBorder = tankCap > 0 ? (galAtBorder / tankCap) * 100 : 0;
        if (pctAtBorder < topOffPct - EPS) {
          borderToppedOff = true;
          usedBorderTopOff = true;
          applyFuelStop(lastPreBorder, false, false, true);
          continue;
        }
      }
    }

    // Reached — fuel and legal drive both cover the rest of the trip.
    if (fuelMi + EPS >= remaining && driveMi + EPS >= remaining) {
      // Fuel + legal drive both cover the rest of the trip. Any 30-min break still due before the end is the
      // driver's own to take — it is not emitted as a stop.
      return done(true, false, gal - galFor(remaining));
    }

    const fuelBinds = fuelMi <= driveMi + EPS;
    const inWindow = stations.filter((x) => !used.has(x.id) && x.milesAhead > pos + EPS && (x.milesAhead - pos) + x.detourMiles <= windowMi + EPS);

    // Break falls due before we must stop and no station sits inside the break window. Advance the break clock
    // (so the NEXT fuel stop is correctly tagged coversBreak) but emit NO rest node — a 30-min break leaves the
    // fuel range and drive clock effectively unchanged, so it never alters WHERE the truck fuels.
    if (hosKnown && breakMi + EPS < windowMi && !inWindow.some((x) => x.milesAhead - pos <= breakMi + EPS)) {
      const at = pos + breakMi;
      gal -= galFor(breakMi);
      drive -= breakMi * msPerMile; shift -= breakMi * msPerMile + BREAK_MS; cycle -= breakMi * msPerMile;
      brk = BREAK_INTERVAL_MS;
      pos = at;
      continue;
    }

    if (!fuelBinds) {
      // The legal drive clock runs out before fuel does → a 10-hour reset is due. The rest is the driver's HOS
      // obligation and is applied SILENTLY; fuel is planned by RANGE, never inserted just to line up with a rest.
      // Combining a fill INTO the rest is a pure convenience — only when a station sits near the limit AND the
      // truck would take a MEANINGFUL fill (>= the min purchase). If it'd arrive near-full, just rest quietly.
      const combine = inWindow.filter((x) => x.milesAhead - pos >= driveMi - COMBINE_BAND_MI);
      if (combine.length === 0) { silentResetAt(pos + driveMi); continue; }
      const { pick, emergency, offNetwork } = pickStop(combine);
      const arrivalGalAtPick = gal - galFor((pick.milesAhead - pos) + pick.detourMiles);
      if (usable - arrivalGalAtPick < cfg.minPurchaseGal) { silentResetAt(pos + driveMi); continue; }
      applyFuelStop(pick, emergency, true, false, offNetwork);
      continue;
    }

    // Fuel is the binding constraint → refuel (full fill, no reset). DEFER the stop toward the reserve so the
    // tank runs down (fewest stops) instead of topping off early at a station the truck merely passes: prefer a
    // preferred, priced station in the last `refuelBandMiles` of range. Fall back to the full reachable set when
    // that band has no good station (sparse stations) so we never strand the route or skip an emergency option.
    if (inWindow.length === 0) {
      // Nothing reachable ABOVE reserve. Case (b): if the truck is critically low (missed a planned fill), let it
      // dip into the reserve to reach the NEAREST station (any brand) as a genuine emergency, rather than strand.
      const curPct = tankCap > 0 ? (gal / tankCap) * 100 : 0;
      const emergencyRangeMi = gpm > 0 ? gal / gpm : 0; // uses reserve fuel too
      const onReserve = stations.filter((x) => !used.has(x.id) && x.milesAhead > pos + EPS && (x.milesAhead - pos) + x.detourMiles <= emergencyRangeMi + EPS);
      if (curPct <= cfg.criticalFuelPct + EPS && onReserve.length > 0) {
        const near = onReserve.reduce((a, b) => (a.milesAhead <= b.milesAhead ? a : b));
        usedEmergency = true;
        applyFuelStop(near, true, false, false, false);
        continue;
      }
      return done(false, true, null);
    }
    if (inWindow.some((x) => isPreferred(x, cfg) && x.netPrice == null)) droppedNoPrice = true;
    const reachablePreferred = inWindow.filter((x) => isPreferred(x, cfg) && x.netPrice != null);
    let pick: SolverStation;
    let emergency: boolean;
    let offNetwork = false;
    if (reachablePreferred.length === 0) {
      ({ pick, emergency, offNetwork } = pickStop(inWindow)); // no Pilot reachable → off-network or true emergency
    } else {
      // Prefer the cheapest preferred station within the last `refuelBandMiles` of range (near reserve). If none
      // sits that close to the reserve, DRIVE AS FAR AS POSSIBLE — take the farthest reachable preferred station,
      // never a cheap early one — so the tank runs down and the plan keeps the fewest stops.
      emergency = false;
      const inBand = reachablePreferred.filter((x) => (x.milesAhead - pos) + x.detourMiles >= fuelMi - cfg.refuelBandMiles - EPS);
      pick = inBand.length > 0
        ? select(inBand)
        : reachablePreferred.reduce((a, b) => ((a.milesAhead + a.detourMiles) >= (b.milesAhead + b.detourMiles) ? a : b));
    }
    applyFuelStop(pick, emergency, false, false, offNetwork);
  }
  return done(false, true, null); // guard tripped without reaching
}

const sumCost = (stops: PlannedStop[]): number | null =>
  stops.some((s) => s.kind === "fuel" && s.cost == null) ? null : stops.reduce((t, s) => t + (s.cost ?? 0), 0);

/** Plan the fuel + HOS stops for one route. Runs the safe greedy, plus a naive nearest-station baseline for savings. */
export function planFuelStops(input: FuelPlanInput): FuelPlan {
  const flags: string[] = [];
  if (input.truck.gallonsOnHand == null) {
    return { status: "infeasible", stops: [], reachesDestination: false, totalGallons: 0, totalCost: null, arrivalFuelPct: null, savingsVsNaive: null, flags: ["no_fuel_reading_cannot_plan", ...input.truck.flags] };
  }
  if (input.truck.belowReserve) flags.push("starts_below_reserve");

  const smart = runGreedy(input, cheapest);
  if (smart.droppedNoPrice) flags.push("some_stations_missing_price");
  if (smart.usedEmergency) flags.push("emergency_fill_used");
  if (smart.usedOffNetwork) flags.push("off_network_stop_used");
  if (smart.usedAvoidedState) flags.push("avoided_state_fill_used");
  if (smart.usedBorderTopOff) flags.push("topped_off_before_avoided_state");
  if (smart.usedMinFill) flags.push("min_drawdown_partial_fills");
  if (smart.usedEstimatedPrice) flags.push("estimated_prices_used");
  if (smart.usedReset) flags.push("overnight_reset_required");
  if (smart.hosLimited) flags.push("hos_limited");

  if (smart.infeasible) {
    return { status: "infeasible", stops: smart.stops, reachesDestination: false, totalGallons: smart.stops.reduce((t, s) => t + s.fillGal, 0), totalCost: sumCost(smart.stops), arrivalFuelPct: null, savingsVsNaive: null, flags: ["INFEASIBLE_no_reachable_fuel", ...flags, ...input.truck.flags] };
  }

  const naive = runGreedy(input, nearest);
  const smartCost = sumCost(smart.stops);
  const naiveCost = sumCost(naive.stops);
  const savings = smartCost != null && naiveCost != null && !naive.infeasible ? Math.max(0, naiveCost - smartCost) : null;
  const arrivalPct = smart.arrivalGal != null ? (smart.arrivalGal / input.truck.effectiveTankCapacityGal) * 100 : null;

  return {
    status: smart.usedEmergency ? "emergency_used" : "ok",
    stops: smart.stops,
    reachesDestination: smart.reaches,
    totalGallons: smart.stops.reduce((t, s) => t + s.fillGal, 0),
    totalCost: smartCost,
    arrivalFuelPct: arrivalPct != null ? Math.round(arrivalPct * 10) / 10 : null,
    savingsVsNaive: savings != null ? Math.round(savings * 100) / 100 : null,
    flags: [...flags, ...input.truck.flags],
  };
}
